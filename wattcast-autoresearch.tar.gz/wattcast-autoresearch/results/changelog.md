# ⚡ WattCast Autoresearch Changelog

*Agent lab notebook — documents the reasoning behind every experiment.*
*Run `python journal.py` for the auto-generated trend analysis and summary.*

---

<!-- Agent: append one entry per experiment below this line. -->
<!-- Format:
### Experiment N — KEEP / DISCARD
**What I changed:** [one sentence]
**Hypothesis:** [why you thought this would help]
**Result:** MAPE X.XX% (Δ ±X.XX% from previous best)
**What I learned:** [one sentence on what this tells us about the model]
**Next move:** [what this result suggests trying next]
-->

