"""
⑤ ORCHESTRATION — Airflow DAG
Runs the full WattCast pipeline every 30 minutes:

    1. Ingest weather data (Kafka producer)
    2. Ingest grid demand data (Kafka producer)
    3. Consume from Kafka → write to Postgres feature store
    4. Build features + run model → write predictions to Redis

CADENCE RATIONALE:
    30 minutes matches the upstream data cadence — EIA publishes hourly,
    Open-Meteo updates hourly. Scoring more frequently re-processes
    identical inputs. Kafka decouples ingestion from processing so
    tightening to 5-minute cycles (e.g., for real-time SCADA or
    sub-hourly ERCOT SCED pricing) requires only changing
    schedule_interval — no architectural changes.

    At <1 min, Airflow's scheduler becomes the bottleneck and you'd
    swap to Kafka Streams or Flink. The ingestion layer (producers,
    topics, consumers) and serving layer (Redis, FastAPI) stay identical.

The frontend NEVER triggers any of this.
The API NEVER triggers any of this.
This DAG is the ONLY thing that causes computation to happen.
"""
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator

# ─── DAG Configuration ───────────────────────────
default_args = {
    "owner": "wattcast",
    "depends_on_past": False,
    "email_on_failure": True,
    "email_on_retry": False,
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
}

dag = DAG(
    dag_id="wattcast_scoring_pipeline",
    default_args=default_args,
    description="Ingest data, build features, score model, cache forecasts",
    schedule_interval="*/30 * * * *",  # 30 min — matches EIA/Open-Meteo hourly cadence
    # To tighten: "*/15 * * * *" (15 min) or "*/5 * * * *" (5 min, XGBoost-only recommended)
    # Below 1 min: replace Airflow with Kafka Streams/Flink; ingestion + serving layers unchanged
    start_date=datetime(2025, 1, 1),
    catchup=False,
    max_active_runs=1,  # Prevent overlap — only one scoring run at a time
    tags=["wattcast", "ml", "forecasting"],
)


# ─── Task Functions ──────────────────────────────
def ingest_weather():
    """① Pull weather data from APIs → Kafka topic."""
    from src.ingestion.weather_producer import run
    run()


def ingest_grid_demand():
    """① Pull grid demand data from EIA → Kafka topic."""
    from src.ingestion.grid_producer import run
    run()


def consume_to_feature_store():
    """② Kafka topics → Postgres feature store."""
    from src.processing.kafka_consumer import run
    run()


def score_and_cache():
    """② Build features → Run model → Write to Redis + Postgres."""
    from src.processing.batch_scorer import run
    run()


# ─── Tasks ───────────────────────────────────────
t_weather = PythonOperator(
    task_id="ingest_weather",
    python_callable=ingest_weather,
    dag=dag,
)

t_grid = PythonOperator(
    task_id="ingest_grid_demand",
    python_callable=ingest_grid_demand,
    dag=dag,
)

t_consume = PythonOperator(
    task_id="consume_to_feature_store",
    python_callable=consume_to_feature_store,
    dag=dag,
)

t_score = PythonOperator(
    task_id="score_and_cache",
    python_callable=score_and_cache,
    dag=dag,
)


# ─── Dependencies ────────────────────────────────
#
#   ingest_weather ──┐
#                     ├──> consume_to_feature_store ──> score_and_cache
#   ingest_grid    ──┘
#
[t_weather, t_grid] >> t_consume >> t_score
