"""
③ SERVING — FastAPI Server
The entire serving layer. This is what the frontend hits.

CRITICAL DESIGN RULE:
    This server NEVER runs ML models, builds features, or queries raw data.
    It ONLY reads pre-computed results from Redis (fast path)
    or historical data from Postgres (slow path, for charts).

Every endpoint is a cache read. If Redis is empty, we return
a "pipeline not ready" response — we do NOT fall back to computing.
"""
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from enum import Enum

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from src.api.cache import ForecastCache
from src.config import GRID_REGIONS, FORECAST_GRANULARITIES

logger = logging.getLogger(__name__)

# ─── Lifespan: init/cleanup cache connection ─────
cache: ForecastCache | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    global cache
    cache = ForecastCache()
    logger.info("Redis cache connection established")
    yield
    cache.close()
    logger.info("Redis cache connection closed")


# ─── App ─────────────────────────────────────────
app = FastAPI(
    title="WattCast v2 API",
    description="Pre-computed energy demand forecasts. Zero computation at request time.",
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Tighten for production
    allow_methods=["GET"],
    allow_headers=["*"],
)


# ─── Models ──────────────────────────────────────
class Granularity(str, Enum):
    fifteen_min = "15min"
    one_hour = "1h"
    one_day = "1d"


class ForecastResponse(BaseModel):
    region: str
    scored_at: str
    granularity: str
    forecasts: list[dict]


class HealthResponse(BaseModel):
    status: str
    last_scored: str | None
    cache_healthy: bool
    regions_available: int
    scoring_interval_min: int
    scoring_mode: str


# ─── Routes ──────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Pipeline freshness check.
    Returns whether the batch scorer has run recently enough,
    along with the configured scoring cadence and mode.
    """
    from src.config import SCORING_INTERVAL_MINUTES, ModelConfig

    meta = cache.get_pipeline_metadata()
    is_healthy = cache.is_healthy()
    model_config = ModelConfig()

    return HealthResponse(
        status="healthy" if is_healthy else "stale",
        last_scored=meta["scored_at"] if meta else None,
        cache_healthy=is_healthy,
        regions_available=meta["regions_scored"] if meta else 0,
        scoring_interval_min=SCORING_INTERVAL_MINUTES,
        scoring_mode="fast (XGBoost only)" if model_config.fast_mode else "full (3-model ensemble)",
    )


@app.get("/forecasts/{region}", response_model=ForecastResponse)
async def get_forecast(
    region: str,
    granularity: Granularity = Query(default=Granularity.fifteen_min),
):
    """
    Get pre-computed demand forecast for a region.

    This is a Redis read — sub-millisecond response time.
    The forecast was pre-computed by the batch scorer (Airflow).
    """
    # Validate region
    if region.upper() not in GRID_REGIONS:
        raise HTTPException(
            status_code=404,
            detail=f"Unknown region '{region}'. Available: {GRID_REGIONS}",
        )

    # Read from cache (the ONLY data access this endpoint does)
    result = cache.get_forecast(region.upper(), granularity.value)

    if result is None:
        raise HTTPException(
            status_code=503,
            detail=(
                f"No forecast available for {region.upper()}. "
                "The batch pipeline may not have run yet. "
                "Check /health for pipeline status."
            ),
        )

    return ForecastResponse(**result)


@app.get("/forecasts", response_model=list[ForecastResponse])
async def get_all_forecasts(
    granularity: Granularity = Query(default=Granularity.one_hour),
):
    """
    Get forecasts for all 8 grid regions in a single request.
    Uses Redis pipeline for efficient multi-key read.
    """
    results = cache.get_all_regions(granularity.value)

    if not results:
        raise HTTPException(
            status_code=503,
            detail="No forecasts available. Check /health for pipeline status.",
        )

    return [ForecastResponse(**r) for r in results]


@app.get("/regions")
async def list_regions():
    """List available grid regions."""
    return {"regions": GRID_REGIONS}


@app.get("/granularities")
async def list_granularities():
    """List available forecast granularities."""
    return {"granularities": list(FORECAST_GRANULARITIES.keys())}
